# Casa Landing Page

tryna recreate this concept by [tommy sadler](https://dribbble.com/shots/2077558-Casa-Landing-Page)

if you see anything that could be better developed, please [fork](https://github.com/mcansh/casa/fork) or leave as an [issue](https://github.com/mcansh/casa/issues/new) <3
